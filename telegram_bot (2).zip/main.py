import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, filters,
    ConversationHandler, ContextTypes
)

logging.basicConfig(level=logging.INFO)

# Состояния для диалога
NAME, ADDRESS, TIME, PHONE = range(4)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply_keyboard = [['Арендовать', 'Инфо']]
    markup = ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True, resize_keyboard=True)
    await update.message.reply_text(
        "Привет! Я бот для аренды кальяна. Что вы хотите сделать?",
        reply_markup=markup
    )
    return

async def info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "💨 Мы предоставляем кальяны в аренду:
"
        "- Цена: от 1000₽/день
"
        "- Бесплатная доставка в черте города
"
        "- Уголь и табак в комплекте

"
        "Напишите /start чтобы арендовать."
    )

async def rent_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Как вас зовут?")
    return NAME

async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text
    await update.message.reply_text("Укажите адрес доставки:")
    return ADDRESS

async def get_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["address"] = update.message.text
    await update.message.reply_text("На какое время и дату оформить аренду?")
    return TIME

async def get_time(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["time"] = update.message.text
    await update.message.reply_text("Оставьте номер телефона для связи:")
    return PHONE

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["phone"] = update.message.text
    data = context.user_data

    summary = (
        f"📝 Заявка на аренду кальяна:
"
        f"Имя: {data['name']}
"
        f"Адрес: {data['address']}
"
        f"Время: {data['time']}
"
        f"Телефон: {data['phone']}"
    )

    await update.message.reply_text("Спасибо! Мы свяжемся с вами в ближайшее время.")
    await update.message.reply_text(summary)

    # Здесь можно добавить отправку заявки админу
    print(summary)

    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Операция отменена.")
    return ConversationHandler.END

if __name__ == '__main__':
    import os
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    if not TOKEN:
        print("Пожалуйста, установите переменную окружения TELEGRAM_BOT_TOKEN")
        exit(1)

    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Regex("^(Инфо)$"), info))

    rent_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^(Арендовать)$"), rent_start)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_address)],
            TIME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_time)],
            PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_phone)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )

    app.add_handler(rent_conv)

    app.run_polling()
